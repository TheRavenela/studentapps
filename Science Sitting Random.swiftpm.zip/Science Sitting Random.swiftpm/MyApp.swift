import SwiftUI

@main
struct SitSortingApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
