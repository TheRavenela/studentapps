import SwiftUI

// IMPORTANT:
// This file should be named ContentView.swift.
// Do NOT put @main in this file if Xcode already created an App file.

// MARK: - Model

struct TableGroup: Identifiable {
    let id = UUID()
    let number: Int
    let students: [String]
}

// MARK: - Main View

struct ContentView: View {
    let students = [
        "Mr. Science",
        "Enzo",
        "Lisoane",
        "Yazhini",
        "Auguste",
        "Catherine",
        "Meïji",
        "Aara"
    ]
    
    @State private var tables: [TableGroup] = []
    @State private var absentStudents: Set<String> = []
    @State private var pairCounts: [String: Int] = [:]
    @State private var isSorting = false
    @State private var needsConfirmation = false
    @State private var timer: Timer?
    @State private var warningMessage = ""
    
    private let pairCountsKey = "pairCounts"
    private let sortDuration: TimeInterval = 3.0
    private let shuffleSpeed: TimeInterval = 0.12
    
    var availableStudents: [String] {
        students.filter { !absentStudents.contains($0) }
    }
    
    var sortedStudents: [String] {
        students.sorted { $0.localizedCaseInsensitiveCompare($1) == .orderedAscending }
    }
    
    var body: some View {
        GeometryReader { geometry in
            ZStack {
                LinearGradient(
                    colors: [Color.blue.opacity(0.15), Color.white, Color.green.opacity(0.10)],
                    startPoint: .top,
                    endPoint: .bottom
                )
                .ignoresSafeArea()
                
                VStack(spacing: 6) {
                    headerView(geometry: geometry)
                    absentListView(geometry: geometry)
                    actionButtons(geometry: geometry)
                    statusText(geometry: geometry)
                    tableGrid(geometry: geometry)
                    statisticsWindow(geometry: geometry)
                }
                .padding(.top, 6)
                .padding(.horizontal, 8)
            }
        }
        .onAppear {
            loadPairCounts()
            sortStudents()
            needsConfirmation = true
        }
        .onDisappear {
            timer?.invalidate()
        }
    }
    
    // MARK: - UI Sections
    
    func headerView(geometry: GeometryProxy) -> some View {
        VStack(spacing: 4) {
            Image("schoolLogo")
                .resizable()
                .scaledToFit()
                .frame(width: min(geometry.size.width * 0.13, 62), height: min(geometry.size.width * 0.13, 62))
                .padding(4)
                .background(Color.white.opacity(0.9))
                .clipShape(RoundedRectangle(cornerRadius: 12))
                .shadow(radius: 2)
            
            Text("Sitting Arrangement")
                .font(.system(size: min(geometry.size.width * 0.055, 26), weight: .heavy, design: .rounded))
                .multilineTextAlignment(.center)
        }
    }
    
    func absentListView(geometry: GeometryProxy) -> some View {
        VStack(spacing: 5) {
            Text("Absent Today — removed for one spin only")
                .font(.system(size: min(geometry.size.width * 0.034, 15), weight: .heavy, design: .rounded))
            
            LazyVGrid(
                columns: [GridItem(.flexible()), GridItem(.flexible()), GridItem(.flexible()), GridItem(.flexible())],
                spacing: 5
            ) {
                ForEach(students, id: \.self) { student in
                    Button {
                        toggleAbsent(student)
                    } label: {
                        Text(student)
                            .font(.system(size: min(geometry.size.width * 0.03, 13), weight: .bold, design: .rounded))
                            .lineLimit(1)
                            .minimumScaleFactor(0.6)
                            .foregroundColor(absentStudents.contains(student) ? .white : .primary)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 5)
                            .background(absentStudents.contains(student) ? Color.red.opacity(0.85) : Color.white.opacity(0.85))
                            .clipShape(RoundedRectangle(cornerRadius: 10))
                    }
                    .disabled(isSorting)
                }
            }
        }
        .padding(6)
        .background(Color.white.opacity(0.45))
        .clipShape(RoundedRectangle(cornerRadius: 14))
    }
    
    func actionButtons(geometry: GeometryProxy) -> some View {
        HStack(spacing: 10) {
            Button(action: startSortingAnimation) {
                Text(isSorting ? "SPINNING..." : needsConfirmation ? "SPIN AGAIN" : "SORT")
                    .font(.system(size: min(geometry.size.width * 0.045, 21), weight: .bold, design: .rounded))
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 9)
                    .background(isSorting ? Color.gray : Color.orange)
                    .clipShape(RoundedRectangle(cornerRadius: 16))
                    .shadow(radius: 3)
            }
            .disabled(isSorting)
            
            Button(action: confirmPairings) {
                Text("CONFIRM")
                    .font(.system(size: min(geometry.size.width * 0.045, 21), weight: .bold, design: .rounded))
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 9)
                    .background(needsConfirmation && !isSorting ? Color.green : Color.gray.opacity(0.65))
                    .clipShape(RoundedRectangle(cornerRadius: 16))
                    .shadow(radius: 3)
            }
            .disabled(!needsConfirmation || isSorting)
        }
        .padding(.horizontal, 14)
    }
    
    func statusText(geometry: GeometryProxy) -> some View {
        VStack(spacing: 1) {
            Text(isSorting ? "Choosing pairs..." : needsConfirmation ? "Confirm to save these pairings, or spin again." : "\(availableStudents.count) students available")
                .font(.system(size: min(geometry.size.width * 0.03, 14), weight: .semibold, design: .rounded))
                .foregroundColor(.secondary)
                .multilineTextAlignment(.center)
            
            if !warningMessage.isEmpty {
                Text(warningMessage)
                    .font(.system(size: min(geometry.size.width * 0.03, 13), weight: .bold, design: .rounded))
                    .foregroundColor(.red)
                    .multilineTextAlignment(.center)
            }
        }
    }
    
    func tableGrid(geometry: GeometryProxy) -> some View {
        LazyVGrid(
            columns: [GridItem(.flexible()), GridItem(.flexible())],
            spacing: 7
        ) {
            ForEach(tables) { table in
                TableCard(table: table, screenWidth: geometry.size.width)
            }
        }
        .padding(.horizontal, 6)
    }
    
    func statisticsWindow(geometry: GeometryProxy) -> some View {
        VStack(alignment: .leading, spacing: 5) {
            HStack {
                Text("Pairing Statistics")
                    .font(.system(size: min(geometry.size.width * 0.04, 18), weight: .heavy, design: .rounded))
                
                Spacer()
                
                Button("Reset") {
                    resetStatistics()
                }
                .font(.system(size: min(geometry.size.width * 0.032, 14), weight: .bold, design: .rounded))
                .foregroundColor(.red)
            }
            
            ScrollView(.horizontal, showsIndicators: true) {
                VStack(spacing: 0) {
                    matrixHeaderRow(geometry: geometry)
                    
                    ForEach(sortedStudents, id: \.self) { rowStudent in
                        HStack(spacing: 0) {
                            Text(rowStudent)
                                .font(.system(size: min(geometry.size.width * 0.026, 12), weight: .bold, design: .rounded))
                                .lineLimit(1)
                                .minimumScaleFactor(0.55)
                                .frame(width: 92, height: 30)
                                .background(Color.blue.opacity(0.14))
                                .border(Color.black.opacity(0.12), width: 1)
                            
                            ForEach(sortedStudents, id: \.self) { columnStudent in
                                MatrixCell(
                                    value: countForPair(rowStudent, columnStudent),
                                    isSameStudent: rowStudent == columnStudent
                                )
                            }
                        }
                    }
                }
                .background(Color.white.opacity(0.92))
                .clipShape(RoundedRectangle(cornerRadius: 12))
            }
        }
        .padding(7)
        .background(Color.white.opacity(0.55))
        .clipShape(RoundedRectangle(cornerRadius: 16))
    }
    
    func matrixHeaderRow(geometry: GeometryProxy) -> some View {
        HStack(spacing: 0) {
            Text("Student")
                .font(.system(size: min(geometry.size.width * 0.026, 12), weight: .heavy, design: .rounded))
                .frame(width: 92, height: 34)
                .background(Color.blue.opacity(0.22))
                .border(Color.black.opacity(0.12), width: 1)
            
            ForEach(sortedStudents, id: \.self) { student in
                Text(student)
                    .font(.system(size: 10, weight: .heavy, design: .rounded))
                    .multilineTextAlignment(.center)
                    .lineLimit(2)
                    .minimumScaleFactor(0.5)
                    .frame(width: 52, height: 34)
                    .background(Color.blue.opacity(0.22))
                    .border(Color.black.opacity(0.12), width: 1)
            }
        }
    }
    
    // MARK: - Absent Logic
    
    func toggleAbsent(_ student: String) {
        if absentStudents.contains(student) {
            absentStudents.remove(student)
        } else {
            absentStudents.insert(student)
        }
    }
    
    func clearAbsencesAfterOneCycle() {
        absentStudents.removeAll()
    }
    
    // MARK: - 3-second animated randomizer
    
    func startSortingAnimation() {
        timer?.invalidate()
        warningMessage = ""
        needsConfirmation = false
        
        guard availableStudents.count >= 2 else {
            warningMessage = "Mark at least 2 students present before sorting."
            return
        }
        
        isSorting = true
        let studentsForThisCycle = availableStudents
        let startTime = Date()
        
        timer = Timer.scheduledTimer(withTimeInterval: shuffleSpeed, repeats: true) { activeTimer in
            sortStudents(from: studentsForThisCycle, animated: false)
            
            if Date().timeIntervalSince(startTime) >= sortDuration {
                activeTimer.invalidate()
                
                withAnimation(.spring(response: 0.35, dampingFraction: 0.75)) {
                    sortStudents(from: studentsForThisCycle, animated: false)
                    isSorting = false
                    needsConfirmation = true
                    clearAbsencesAfterOneCycle()
                }
            }
        }
    }
    
    func sortStudents(animated: Bool = true) {
        sortStudents(from: availableStudents, animated: animated)
    }
    
    func sortStudents(from studentList: [String], animated: Bool = true) {
        var shuffled = studentList.shuffled()
        var newTables: [TableGroup] = []
        var tableNumber = 1
        
        while shuffled.count >= 2 {
            let pair = [shuffled.removeFirst(), shuffled.removeFirst()]
            newTables.append(TableGroup(number: tableNumber, students: pair))
            tableNumber += 1
        }
        
        if let leftoverStudent = shuffled.first {
            newTables.append(TableGroup(number: tableNumber, students: [leftoverStudent]))
        }
        
        if animated {
            withAnimation(.spring(response: 0.35, dampingFraction: 0.75)) {
                tables = newTables
            }
        } else {
            tables = newTables
        }
    }
    
    // MARK: - Pairing Statistics
    
    func confirmPairings() {
        updatePairCounts(from: tables)
        savePairCounts()
        needsConfirmation = false
        warningMessage = "Pairings saved."
    }
    
    func updatePairCounts(from tables: [TableGroup]) {
        for table in tables where table.students.count == 2 {
            let key = pairKey(table.students[0], table.students[1])
            pairCounts[key, default: 0] += 1
        }
    }
    
    func countForPair(_ first: String, _ second: String) -> Int {
        if first == second { return 0 }
        return pairCounts[pairKey(first, second), default: 0]
    }
    
    func pairKey(_ first: String, _ second: String) -> String {
        [first, second].sorted().joined(separator: "|")
    }
    
    func savePairCounts() {
        UserDefaults.standard.set(pairCounts, forKey: pairCountsKey)
    }
    
    func loadPairCounts() {
        if let savedCounts = UserDefaults.standard.dictionary(forKey: pairCountsKey) as? [String: Int] {
            pairCounts = savedCounts
        }
    }
    
    func resetStatistics() {
        pairCounts = [:]
        UserDefaults.standard.removeObject(forKey: pairCountsKey)
        warningMessage = "Statistics reset."
    }
}

// MARK: - Table Card

struct TableCard: View {
    let table: TableGroup
    let screenWidth: CGFloat
    
    var body: some View {
        VStack(spacing: 5) {
            Text("Table \(table.number)")
                .font(.system(size: min(screenWidth * 0.035, 16), weight: .bold, design: .rounded))
                .foregroundColor(.blue)
            
            ForEach(table.students, id: \.self) { student in
                Text(student)
                    .font(.system(size: min(screenWidth * 0.036, 17), weight: .semibold, design: .rounded))
                    .lineLimit(1)
                    .minimumScaleFactor(0.65)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 5)
                    .padding(.horizontal, 4)
                    .background(Color.white)
                    .clipShape(RoundedRectangle(cornerRadius: 10))
                    .shadow(color: .black.opacity(0.08), radius: 2, x: 0, y: 2)
            }
            
            if table.students.count == 1 {
                Text("Solo")
                    .font(.system(size: min(screenWidth * 0.028, 12), weight: .bold, design: .rounded))
                    .foregroundColor(.secondary)
            }
        }
        .padding(7)
        .frame(maxWidth: .infinity, minHeight: 88)
        .background(Color.white.opacity(0.78))
        .clipShape(RoundedRectangle(cornerRadius: 14))
        .shadow(color: .black.opacity(0.12), radius: 2, x: 0, y: 2)
    }
}

// MARK: - Matrix Cell

struct MatrixCell: View {
    let value: Int
    let isSameStudent: Bool
    
    var body: some View {
        Text(isSameStudent ? "—" : "\(value)")
            .font(.system(size: 13, weight: .heavy, design: .rounded))
            .foregroundColor(isSameStudent ? .secondary : .primary)
            .frame(width: 52, height: 30)
            .background(isSameStudent ? Color.gray.opacity(0.35) : Color.white.opacity(0.95))
            .border(Color.black.opacity(0.12), width: 1)
    }
}

#Preview {
    ContentView()
}

